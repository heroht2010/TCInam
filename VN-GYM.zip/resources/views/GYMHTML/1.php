<?php 
echo "Chào thế giới";
 ?>