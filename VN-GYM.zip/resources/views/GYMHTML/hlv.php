<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1 style="color: #FFF056">Trang của HLV <?php echo $_SESSION['hlv']; ?> đang được nâng cấp</h1>
</body>
</html>