<!DOCTYPE html>
<html>
<head>
	<title>VNGYM - The World Of Gymer</title>
	 	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/GYMCSS/listpay.css')); ?>">
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../GYMJS/hinhhover.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css'>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="icon" href="‪C:\Users\Lenovo\Desktop\logo.png" type="image/x-ico"/>
<link href="https://fonts.googleapis.com/css?family=Mitr&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Jockey+One|Montserrat&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Saira+Semi+Condensed&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Paytone+One&display=swap" rel="stylesheet">
</head>

<body>

   
   <?php echo $__env->make("GYMHTML.navbar_admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div class="frame">

     <div class="menu">
       <?php echo $__env->make("GYMHTML.menuadmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     </div>

      <div class="content">
       <p style="font-size: 25px;font-family: Montserrat;"><i class='fas fa-truck' style="margin-right: 1%"></i><b>DANH SÁCH ĐƠN HÀNG</b></p>
       <p style="font-family: Montserrat;font-size: 18px">Thống kê đơn hàng vào</p>
         <a href="<?php echo e(route('theongay')); ?>"><button class="btn-day">Theo ngày</button></a>
         <form action="<?php echo e(route('tkpay')); ?>" method="POST">
         <?php echo csrf_field(); ?>
             <input type="date" name="start"> - 
             <input type="date" name="end">
             <button class="btn-day" type="submit">Thống kê</button>
         </form>
       <p>
       </p>
       <table class="table table-bordered" style="background-color: white">
    <thead>
      <tr>
        <th>ID</th>
        <th>Người dùng</th>
        <th>Image</th>
        <th>Tên</th>
        <th>Trọng lượng</th>
        <th>Hương vị</th>
        <th>Số lượng</th>
        <th>Đơn giá</th>
        <th>Đơn vị vận chuyển</th>
        <th>Tổng tiền</th>
        <th>Note</th>
        <th>Ngày tạo</th>
        <th>Ngày nhận</th>
        <th>Trạng thái</th>
      </tr>
    </thead>
    <tbody>
      <?php $i=0; ?>
      
      <?php foreach ($data as $key => $value): ?>
        
      <tr>
        <td><?php echo $i=$i+1; ?></td>
        <td><?php echo $value->customer()->get()->first()->ten;echo " "; echo $value->customer()->get()->first()->ho?></td>
        <td ><img src="../upload/product/<?php echo $value->product()->get()->first()->image ?>" style="height: 100px;width: 100px"></td>
        <td><?php echo $value->product()->get()->first()->name ?></td>
        <td><?php echo $value->product()->get()->first()->weight ?></td>
        <td><?php echo $value['huongvisp'] ?></td>
        <td><?php echo $value['soluong'] ?></td>
        <td><?php echo $value['dongia'] ?></td>
        <td><?php echo $value['vanchuyen'] ?></td>
        <td><?php echo $value['tongtien'] ?></td>
        <td><?php echo $value['note'] ?></td>
        <td><?php echo $value->donhang()->get()->first()->ngaytao ?></td>
        <td><?php echo $value->donhang()->get()->first()->ngaynhan ?></td>
        <td><?php 
          if (($value->donhang()->get()->first()->trangthai)=='cho') {
            echo "ĐANG XÁC NHẬN";
          }
          else{
            if (($value->donhang()->get()->first()->trangthai)=='dang') {
              echo "ĐANG GIAO";
            }
            else{
              if (($value->donhang()->get()->first()->trangthai)=='da') {
                echo "ĐÃ GIAO";
              }
              else{
                echo "ĐÃ HỦY";
              }
            }
          }
         ?></td>
        <td style="color: green"><i class="fa fa-refresh"></i><a href="<?php echo e(route('editpay')); ?>?id=<?php echo $value['id'] ?>">Sửa</a></td>
        <td style="color: red"><i class="glyphicon glyphicon-trash"></i>Xóa</td>
      </tr>
      
      <?php endforeach ?>
    </tbody>
  </table>
      </div>
   </div>

</body>
<script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

</html><?php /**PATH D:\xampp\htdocs\VN-GYM\resources\views/GYMHTML/GYM-listpayadmin.blade.php ENDPATH**/ ?>