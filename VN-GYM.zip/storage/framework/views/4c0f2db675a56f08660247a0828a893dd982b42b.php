<!DOCTYPE html>
<html>
<head>
	<title>VNGYM - The World Of Gymer</title>
	 	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/GYMCSS/admin.css')); ?>">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../GYMJS/hinhhover.js"></script>
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css'>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="icon" href="‪C:\Users\Lenovo\Desktop\logo.png" type="image/x-ico"/>
<link href="https://fonts.googleapis.com/css?family=Mitr&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Jockey+One|Montserrat&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Saira+Semi+Condensed&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Paytone+One&display=swap" rel="stylesheet">
</head>

<body>

   
    <div class="navtop">
          <div class="navtopleft"></div>
          <div class="navtopright">
            <div class="dropdown">
 <a href="../HTML/chuacokinhnghiem.html" style="font-size: 15px;font-family: Montserrat;text-decoration: none;outline: none;color: white" class="hovertext">
  <img src="https://tintuc.viettelstore.vn/wp-content/uploads/2018/10/che-do-an-danh-chrome-1.png" style="height: 50px;border-radius: 50%;width: 30%;margin-right: 3px;float: left;"><b style="float: left;padding-top: 5%;">Admin</b><i class="fa fa-caret-down" style="float: left;padding-top: 5%"></i></a>
  <div class="dropdown-content" style="margin-top: 26%;">
    <a href="#" style="text-decoration: none;"><span class="glyphicon glyphicon-user" style="margin-right: 3%"></span>Nhật Ký</a>
    <a href="../GYMHTML/GYM-giohang.php" style="text-decoration: none;"><span class="glyphicon glyphicon-shopping-cart" style="margin-right: 3%"></span>Góc Riêng</a>
    <a href="#" style="text-decoration: none;"><span class="glyphicon glyphicon-heart" style="margin-right: 3%"></span>Cất Giữ Tình Yêu</a>
    <a href="<?php echo e(route('dangxuat')); ?>" style="text-decoration: none;"><span class="glyphicon glyphicon-log-out" style="margin-right: 3%"></span>Đăng Xuất</a>
  </div>
</div>
          </div>
        </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\VN-GYM\resources\views/GYMHTML/navbar_admin.blade.php ENDPATH**/ ?>