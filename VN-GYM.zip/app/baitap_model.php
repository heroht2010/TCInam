<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baitap_model extends Model
{
    //
    protected $table='baitap';
}
