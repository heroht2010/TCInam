<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class customer_model extends Model
{
    //
    protected $table='customer';
    public $timestamps=false;
}
