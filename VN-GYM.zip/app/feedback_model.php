<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class feedback_model extends Model
{
    //
    protected $table='response';
}
