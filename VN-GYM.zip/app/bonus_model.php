<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bonus_model extends Model
{
    //
    protected $table='bonus';
    public $timestamps=false;
}
